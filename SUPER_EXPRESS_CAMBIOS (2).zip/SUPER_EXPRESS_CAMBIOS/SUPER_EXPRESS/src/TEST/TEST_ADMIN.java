package TEST;

import GUI.PLATAFORMA_ADMIN;

public class TEST_ADMIN {
    public static void main(String[] args) {
        PLATAFORMA_ADMIN nuevo = new PLATAFORMA_ADMIN();
        nuevo.setVisible(true);
      
    }
}
