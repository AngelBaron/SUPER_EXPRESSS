/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;
import LOGICA.Encriptar;
/**
 *
 * @author lucho
 */
public class TESTENCRIPTACION {
    public static void main(String[] args) {
        Encriptar en = new Encriptar();
        System.out.println(en.Encriptar("Hollaaa"));
        System.out.println(en.Desencriptar(en.Encriptar("Hollaaa")));
    }
}
