/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LOGICA;

/**
 *
 * @author lucho
 */
public class ImprimirPDFJava {
    static String impresora = "Microsoft Print to PDF";
    static String serial ="";
    static String grados ="0";
    static String direccionServidor = "http://localhost:8080";
    
    public static void ejemploUrl(){
        
    }
    
}
