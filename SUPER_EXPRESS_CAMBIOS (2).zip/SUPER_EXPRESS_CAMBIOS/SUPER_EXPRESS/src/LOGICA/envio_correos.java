/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LOGICA;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

/**
 *
 * @author lucho
 */
public class envio_correos {

    String emailFrom = "luchogar522@gmail.com";
    String passwordFrom = "jamqayhqideuslwx";
    String emailTo = "";
    String subject = "";
    String content = "";
    Properties mProperties = new Properties();
    Session mSession;
    MimeMessage mCorreo;

    public void crearCorreo(String correoUsuario, String tema, String contenido) {
        try {
            emailTo = correoUsuario;
            subject = tema;
            content = contenido;

            mProperties.put("mail.smtp.host", "smtp.gmail.com");
            mProperties.put("mail.smtp.ssl.trust", "smtp.gmail.com");
            mProperties.setProperty("mail.smtp.starttls.enable", "true");
            mProperties.setProperty("mail.smtp.port", "587");
            mProperties.setProperty("mail.smtp.user", emailFrom);
            mProperties.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");
            mProperties.setProperty("mail.smtp.auth", "true");

            mSession = Session.getDefaultInstance(mProperties);
            mCorreo = new MimeMessage(mSession);
            mCorreo.setFrom(new InternetAddress(emailFrom));
            mCorreo.setRecipient(Message.RecipientType.TO, new InternetAddress(emailTo));
            mCorreo.setSubject(subject);
            mCorreo.setText(content, "ISO-8859-1", "html");
        } catch (AddressException ex) {
            Logger.getLogger(envio_correos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(envio_correos.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            Transport mTransport = mSession.getTransport("smtp");
            mTransport.connect(emailFrom, passwordFrom);
            mTransport.sendMessage(mCorreo, mCorreo.getRecipients(Message.RecipientType.TO));
            mTransport.close();
            JOptionPane.showMessageDialog(null, "SE HA ENVIADO EL COORREO");
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(envio_correos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(envio_correos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendEmail() {

    }

    public void enviarCorreo_pedido_usuario(String correoUsuario, String nombreProducto, String codigoProducto, int cantidad, double precio) {
        // Configuración del servidor de correo
        String host = "smtp.gmail.com";
        String puerto = "587";
        String usuario = "luchogar522@gmail.com"; // correo desde donde se envia 
        String contraseña = "jamqayhqideuslwx"; // La contraseña de la aplicación generada

        // Propiedades del correo
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", puerto);
        props.put("mail.smtp.ssl.trust", host);

        // Crear una nueva sesión de correo
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(usuario, contraseña);
            }
        });

        try {
            // Crear mensaje de correo de confirmación de compra
            Message mensajeConfirmacion = new MimeMessage(session);
            mensajeConfirmacion.setFrom(new InternetAddress(usuario));
            mensajeConfirmacion.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoUsuario));
            mensajeConfirmacion.setSubject("Confirmación de compra");
            mensajeConfirmacion.setText("Su compra ha sido confirmada.\n\nDetalles de la compra:\n\n"
                    + "Nombre del producto: " + nombreProducto + "\n"
                    + "Código del producto: " + codigoProducto + "\n"
                    + "Cantidad: " + cantidad + "\n"
                    + "Precio: " + precio + "\n\n"
                    + "¡Gracias por su compra!");

            // Enviar correo de confirmación de compra
            Transport.send(mensajeConfirmacion);

            System.out.println("Se ha enviado un correo de confirmación de compra a " + correoUsuario);
        } catch (MessagingException e) {
            System.out.println("Error al enviar el correo: " + e.getMessage());
        }
    }

    public void enviarCorreo_pedido_admin(String correoUsuario, String nombreProducto, String codigoProducto, int cantidad, double precio) {
        // Configuración del servidor de correo
        String host = "smtp.gmail.com";
        String puerto = "587";
        String usuario = "gaby100195@gmail.com";// correo desde donde se envia 
        String contraseña = "pfet muqt qvib vcow";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", puerto);

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(usuario, contraseña);
            }
        });

        try {
            // Crear mensaje de correo de confirmación de compra
            Message mensajeConfirmacion = new MimeMessage(session);
            mensajeConfirmacion.setFrom(new InternetAddress(usuario));
            mensajeConfirmacion.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoUsuario));
            mensajeConfirmacion.setSubject("SOLICITUD DE PEDIDO");
            mensajeConfirmacion.setText("Hay una nueva solicitud de pedido.\n\n Detalles del pedido:\n\n"
                    + "Nombre del producto: " + nombreProducto + "\n"
                    + "Código del producto: " + codigoProducto + "\n"
                    + "Cantidad: " + cantidad + "\n"
                    + "Precio: " + precio + "\n\n"
                    + "¡Gracias por su compra!");

            // Enviar correo de confirmación de compra
            Transport.send(mensajeConfirmacion);

            System.out.println("Se ha enviado un correo de confirmación de compra a " + correoUsuario);
        } catch (MessagingException e) {
            System.out.println("Error al enviar el correo: " + e.getMessage());
        }
    }

    public void correo_agregar_producto(String correoUsuario, String nombreProducto, String codigoProducto, int cantidad, double precio, String des) {
        // Configuración del servidor de correo
        String host = "smtp.gmail.com";
        String puerto = "587";
        String usuario = "gaby100195@gmail.com";// correo desde donde se envia 
        String contraseña = "pfet muqt qvib vcow";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", puerto);

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(usuario, contraseña);
            }
        });

        try {
            // Crear mensaje de correo de confirmación de compra
            Message mensajeConfirmacion = new MimeMessage(session);
            mensajeConfirmacion.setFrom(new InternetAddress(usuario));
            mensajeConfirmacion.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoUsuario));
            mensajeConfirmacion.setSubject("SOLICITUD DE PEDIDO");
            mensajeConfirmacion.setText("Hay una nueva solicitud de pedido.\n\n Detalles del pedido:\n\n"
                    + "Nombre del producto: " + nombreProducto + "\n"
                    + "Código del producto: " + codigoProducto + "\n"
                    + "Cantidad: " + cantidad + "\n"
                    + "Precio: " + precio + "\n\n"
                    + "Descripcion" + des + "\n\n"
                    + "¡Gracias por su compra!");

            // Enviar correo de confirmación de compra
            Transport.send(mensajeConfirmacion);

            System.out.println("Se ha enviado un correo de confirmación de compra a " + correoUsuario);
        } catch (MessagingException e) {
            System.out.println("Error al enviar el correo: " + e.getMessage());
        }
    }

    public void correo_modificacion_producto(String correoUsuario, String nombreProducto, String codigoProducto, int cantidad, double precio, String des) {
        // Configuración del servidor de correo
        String host = "smtp.gmail.com";
        String puerto = "587";
        String usuario = "gaby100195@gmail.com";// correo desde donde se envia 
        String contraseña = "pfet muqt qvib vcow";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", puerto);

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(usuario, contraseña);
            }
        });

        try {
            // Crear mensaje de correo de confirmación de compra
            Message mensajeConfirmacion = new MimeMessage(session);
            mensajeConfirmacion.setFrom(new InternetAddress(usuario));
            mensajeConfirmacion.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoUsuario));
            mensajeConfirmacion.setSubject("SOLICITUD DE PEDIDO");
            mensajeConfirmacion.setText("Hay una nueva solicitud de pedido.\n\n Detalles del pedido:\n\n"
                    + "Nombre del producto: " + nombreProducto + "\n"
                    + "Código del producto: " + codigoProducto + "\n"
                    + "Cantidad: " + cantidad + "\n"
                    + "Precio: " + precio + "\n\n"
                    + "Descripcion" + des + "\n\n"
                    + "¡Gracias por su compra!");

            // Enviar correo de confirmación de compra
            Transport.send(mensajeConfirmacion);

            System.out.println("Se ha enviado un correo de confirmación de compra a " + correoUsuario);
        } catch (MessagingException e) {
            System.out.println("Error al enviar el correo: " + e.getMessage());
        }
    }

}
