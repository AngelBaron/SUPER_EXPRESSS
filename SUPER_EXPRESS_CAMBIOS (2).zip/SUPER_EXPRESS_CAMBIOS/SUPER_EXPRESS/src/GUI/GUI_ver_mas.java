/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class GUI_ver_mas extends JFrame implements ActionListener {

    Font letra_titulo = new Font("Lucida Sans", Font.BOLD, 50);
    Font letra_boton = new Font("Lucida Sans", Font.PLAIN, 25);
    String nombre, desc, eti;
    int  can, pre;
    long cod;
    Image img;
    JLabel tit, lbl_des;
    JTextArea us_des;
    JLabel txtimg, txt_pre;
    JButton anadir;
    JButton canc;
    PLATAFORMA_US obj;

    public GUI_ver_mas(String nombre, String desc, long cod, int can, Image img, int pre, PLATAFORMA_US obj, String eti) {
        this.nombre = nombre;
        this.desc = desc;
        this.cod = cod;
        this.can = can;
        this.img = img;
        this.pre = pre;
        this.obj = obj;
        this.eti = eti;

        setTitle("PRODUCTO " + nombre);
        setIconImage(new ImageIcon(getClass().getResource("/IMAGENES/producto.png")).getImage());

        setResizable(false);
        setSize(780, 630);
        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            System.out.println(ex);
        }

        setLayout(null);
        setLocationRelativeTo(null);
//        Configuración del color de fondo con degradado
        GradientPanel panel = new GradientPanel();
        setContentPane(panel);
        comp();
        setVisible(true);
    }

    public void comp() {
        // Ajustes para el panel con degradado de fondo
        GradientPanel panel = new GradientPanel();
        panel.setLayout(null);
        panel.setBounds(0, 0, getWidth(), getHeight());
        setContentPane(panel);

        // Ajustes para la imagen
        ImageIcon originalIcon = new ImageIcon(img);
        txtimg = new JLabel();
        txtimg.setBounds(420, 150, 300, 300); // Posición y tamaño de la imagen
        txtimg.setBorder(BorderFactory.createLineBorder(new Color(24, 175, 90), 5)); // Borde negro de 2 píxeles
        panel.add(txtimg);
        Image scalImage = originalIcon.getImage().getScaledInstance(txtimg.getWidth(), txtimg.getHeight(), Image.SCALE_SMOOTH);
        txtimg.setIcon(new ImageIcon(scalImage));

        tit = new JLabel(nombre);
        tit.setBounds(100, 50, 200, 70);
        tit.setFont(letra_titulo);
        panel.add(tit);

        // Ajustes para el precio
        txt_pre = new JLabel("$" + pre);
        txt_pre.setBounds(400, 50, 600, 70);
        txt_pre.setFont(letra_titulo);
        panel.add(txt_pre);

        // Ajustes para la descripción
        lbl_des = new JLabel("DESCRIPCIÓN");
        lbl_des.setFont(letra_boton);
        lbl_des.setBounds(10, 100, 200, 50);
        panel.add(lbl_des);

        us_des = new JTextArea();
        us_des.setBounds(10, 150, 340, 300);
        us_des.setOpaque(false); // JTextArea sea transparente
        us_des.setBackground(new Color(0, 0, 0, 0)); //  de fondo transparente
        us_des.setLineWrap(true);
        us_des.setWrapStyleWord(true);
        us_des.setEditable(false);
        us_des.setText(desc);
        panel.add(us_des);

        // Ajustes para el botón "AÑADIR"
        anadir = new JButton("Añadir");
        anadir.setBounds(540, 500, 150, 60);
        anadir.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        anadir.addActionListener(this);

        anadir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                anadir.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                anadir.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                anadir.setBackground(new Color(24, 175, 90)); //  restaurar color de verde metalico
                anadir.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        anadir.setBackground(new Color(24, 175, 90)); //  color de fondo a verde metalico
        anadir.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
        panel.add(anadir);

        // Ajustes para el botón "CANCELAR"
        canc = new JButton("Cancelar");
        canc.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        canc.addActionListener(this);

        canc.setBounds(50, 500, 150, 60); // Posición y tamaño del botón "CANCELAR"
        canc.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                canc.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                canc.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                canc.setBackground(new Color(24, 175, 90)); //  restaurar color de verde metalico
                canc.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        canc.setBackground(new Color(24, 175, 90)); //  color de verde metalico
        canc.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
        panel.add(canc);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == canc) {
            setVisible(false);
        }

        if (e.getSource() == anadir) {
            try {
                int c = Integer.parseInt(JOptionPane.showInputDialog(null, "¿CUANTOS PRODUCTOS QUIERES?"));
                int it = 0;
                if (obj.cod_can.containsKey(cod)) {

                    for (int i = 0; i < obj.codigos_g.size(); i++) {
                        if (obj.codigos_g.get(i) == cod) {
                            c += obj.cantidades_g.get(i);
                            it = i;
                        }
                    }
                    if (c > can) {
                        JOptionPane.showMessageDialog(null, "LA CANTIDAD AÑADIDA EXCEDE EL LIMITE");
                    } else if (c < 0) {
                        JOptionPane.showMessageDialog(null, "LA CANTIDAD AÑADIDA Y EL ANTERIOR DA NUMERO NEGATIVO");
                    } else {
                        obj.cod_can.put(cod, c);
                        obj.cantidades_g.set(it, c);
                    }

                } else {
                    System.out.println(cod);
                    System.out.println("NO HAY LLAVE");

                    if (c > can) {
                        JOptionPane.showMessageDialog(null, "LA CANTIDAD EXCEDE DEL LIMITE");
                    } else if (c < 0) {
                        JOptionPane.showMessageDialog(null, "LA CANTIDAD TIENE QUE SER MÁS DE 1");
                    } else {
                        obj.nombres_g.add(nombre);
                        obj.cantidades_g.add(c);
                        obj.codigos_g.add(cod);
                        obj.precio_g.add(pre);
                        obj.etiquetas_g.add(eti);
                        obj.imageBytes_g.add(img);
                        obj.cod_can.put(cod, c);
                    }
                }

            } catch (Exception s) {
                JOptionPane.showMessageDialog(null, "ERROR EN LOS DATOS");
            }
        }
    }

    class GradientPanel extends JPanel {

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int w = getWidth();
            int h = getHeight();
//            Color color1 = new Color(255, 255, 0); // Amarillo
//            Color color2 = new Color(255, 255, 255); // Blanco
//            Color color1 = new Color(173, 216, 230); // Azul claro
//            Color color2 = new Color(0, 128, 0); // Verde oscuro
            Color color1 = new Color(255, 255, 255); // Blanco
            Color color2 = new Color(144, 238, 144); // Verde claro 
            GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
        }
    }
}
